-- Advance Questions : 

-- 1) Retrieve the total number of books sold for each genre:
SELECT 
    b.genre, SUM(o.Quantity)
FROM
    orders o
        JOIN
    books b ON o.Book_ID = b.Book_ID
GROUP BY b.genre;


-- 2) Find the average price of books in the "Fantasy" genre:
SELECT 
    ROUND(AVG(Price), 2) AS Average_Price
FROM
    books
WHERE
    Genre = 'Fantasy';


-- 3) List customers who have placed at least 2 orders:
SELECT 
    o.Customer_ID, c.Name, COUNT(o.Order_ID) AS Order_Count
FROM
    orders o
        JOIN
    customers c ON o.Customer_ID = c.Customer_ID
GROUP BY o.Customer_ID , c.Name
HAVING COUNT(Order_ID) >= 2;


-- 4) Find the most frequently ordered book:
SELECT 
    o.Book_ID, b.Title, COUNT(o.Order_ID) AS Order_Count
FROM
    orders o
        JOIN
    books b ON o.Book_ID = b.Book_ID
GROUP BY o.Book_ID , b.Title
ORDER BY Order_Count DESC
LIMIT 1;

-- 5) Show the top 3 most expensive books of 'Fantasy' Genre :
SELECT 
    *
FROM
    books
WHERE
    genre = 'Fantasy'
ORDER BY Price DESC
LIMIT 3;


-- 6) Retrieve the total quantity of books sold by each author:
SELECT 
    b.Author, SUM(o.Quantity) AS Total_Books_Sold
FROM
    orders o
        JOIN
    books b ON o.Book_ID = b.Book_ID
GROUP BY b.Author;


-- 7) List the cities where customers who spent over $30 are located:
SELECT DISTINCT
    c.City, Total_Amount
FROM
    orders o
        JOIN
    customers c ON o.Customer_ID = c.Customer_ID
WHERE
    Total_Amount > 30;


-- 8) Find the customer who spent the most on orders:
SELECT 
    c.Customer_ID, c.Name, SUM(o.Total_Amount) AS Total_Spend
FROM
    orders o
        JOIN
    customers c ON o.Customer_ID = c.Customer_ID
GROUP BY c.Customer_ID , c.Name
ORDER BY Total_Spend DESC
LIMIT 1;

-- 9) Calculate the stock remaining after fulfilling all orders:
SELECT b.book_id, b.title, b.stock, COALESCE(SUM(o.quantity),0) AS Order_quantity,  
	b.stock- COALESCE(SUM(o.quantity),0) AS Remaining_Quantity
FROM books b
LEFT JOIN orders o ON b.book_id=o.book_id
GROUP BY b.book_id ORDER BY b.book_id;