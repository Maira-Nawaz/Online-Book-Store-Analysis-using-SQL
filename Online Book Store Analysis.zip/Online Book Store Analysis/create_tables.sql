CREATE DATABASE online_book_store;


CREATE TABLE Books(
Book_ID SERIAL Primary Key,
Title VARCHAR(100),
Author VARCHAR(100),
Genre VARCHAR(50),
Published_Year INT,
Price Numeric(10, 2),
Stock INT
);


CREATE TABLE Customers(
Customer_ID SERIAL Primary Key,
Name VARCHAR(100),
Email VARCHAR(100),
Phone VARCHAR(15),
City VARCHAR(50),
Country VARCHAR(50)
);


CREATE TABLE Orders(
Order_ID SERIAL Primary Key,
Customer_ID INT References Customers(Customer_ID),
Book_ID INT References Books(Book_ID),
Order_Date DATE,
Quantity INT,
Total_Amount NUMERIC(10, 2)
);
